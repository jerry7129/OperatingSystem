#include "kernel/types.h"
#include "user/user.h"
#include "user/thread.h"

#define NTHREAD 2


// 스레드에서 실행할 함수
void thread_main(void *arg1, void *arg2) {
  int id = *(int *)arg1;
  char *msg = (char *)arg2;
  printf("Thread %d: %s\n", id, msg);
  exit(0);  // 스레드 종료
}

int
main()
{
  int i;
  int tids[NTHREAD];
  int args[NTHREAD];
  char *msg = "Hello from thread!";

  printf("Main: creating %d threads\n", NTHREAD);

  for(i = 0; i < NTHREAD; i++) {
    args[i] = i;
    tids[i] = thread_create(thread_main, &args[i], msg);
    if(tids[i] < 0) {
      printf("Main: thread_create failed at %d\n", i);
      exit(1);
    }
  }

  for(i = 0; i < NTHREAD; i++) {
    int pid = thread_join();
    if(pid < 0) {
      printf("Main: thread_join failed\n");
      exit(1);
    } else {
      printf("Main: joined thread with pid %d\n", pid);
    }
  }

  printf("Main: all threads joined. Test passed.\n");
  exit(0);
}
