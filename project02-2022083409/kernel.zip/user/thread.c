#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "user/thread.h"

int
thread_create(void (*start_routine)(void *, void *), void *arg1, void *arg2)
{
  void *base = malloc(2 * PGSIZE);
  void *stack = (void *)(((uint64)base + PGSIZE - 1) & ~(PGSIZE - 1));
  if ((uint64)stack % PGSIZE != 0)
    return -1;

  int pid = clone(start_routine, arg1, arg2, stack);
  if (pid < 0)
    return -1;

  return pid;
}

int
thread_join()
{
  void *stack;
  int pid = join(&stack);
  if(pid < 0)
    return -1;

  return pid;
}